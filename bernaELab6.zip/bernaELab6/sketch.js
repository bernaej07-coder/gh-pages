let pumpkinYPosition = [];
let numofpumpkins = 4;
let currentDirection = 0.5; 

function setup() {
  createCanvas(400, 400);
  
  for (let i = 0; i < numofpumpkins; i++) { 
    pumpkinYPosition[i] = height / 2; 
  }
  
  console.log('Pumpkins: ' + numofpumpkins);
}

function draw() {
  background(10); 
  noStroke();

  if (pumpkinYPosition[0] > 400 || pumpkinYPosition[0] < 100) {
    currentDirection *= -1;
  }

  for (let i = 0; i < numofpumpkins; i++) {
    
    pumpkinYPosition[i] += currentDirection;

    let xPosition = 50 + (i * 90);
    let size = 40 + (i * 2) * 7; 
    let yPosition = pumpkinYPosition[i];

    fill('orange');
    ellipse(xPosition, yPosition, size, size); 
 
    fill(0);
    
    ellipse(xPosition - size * 0.1, yPosition - size * 0.1, 3, 3);
    ellipse(xPosition + size * 0.1, yPosition - size * 0.1, 3, 3);

    rect(xPosition - size * 0.25, yPosition + size * 0.25, size * 0.5, 5); 
  }
}