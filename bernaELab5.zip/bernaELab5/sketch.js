let ballX;
let ballY;
let directionX;
let directionY;
let ballColor; // Variable to hold the ball's color

function setup() {
  createCanvas(400, 400);
  background(220);
  frameRate(60);
  ballX = width / 2;
  ballY = height / 2;
  directionX = random(-5, 5);
  directionY = random(-5, 5);
  ballColor = color(0); // Initialize ball color to black
}

function draw() {
  background(220);
  fill(ballColor); // Use the ballColor variable to set the fill color
  circle(ballX, ballY, 50);

  ballX = ballX + directionX;
  ballY = ballY + directionY;

  if (ballX >= 400 || ballY >= 400 || ballY <= 0 || ballX <= 0) {
    ballX = random(0, 400);
    ballY = random(0, 400);
    directionX = random(-5, 5);
    directionY = random(-5, 5);
  }
  while(false){}
}

// This function is called automatically once every time the mouse is pressed
function mousePressed() {
  // Pick new random red, green, and blue values
  let r = random(255);
  let g = random(255);
  let b = random(255);
  // Create a new color and assign it to the ballColor variable
  ballColor = color(r, g, b);
}
function keyPressed() {
  // Pause and unpause the animation.
  if (isLooping()) {
    noLoop();
  } else {
    loop()
  }
}