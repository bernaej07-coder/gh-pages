let ballX; 
let ballY;
let directionX = 5;
let directionY = 2;



function setup() {
  createCanvas(400, 400);
  background(220);
  frameRate(60);
  ballX = width/2;
  ballY = width/2;
directionX = random(-5,5)
  directionY = random(-5,5)
  
  


}

function draw() {
  background(220);
  circle(ballX,ballY, 50);
ballX = ballX + directionX 
  ballY = ballY + directionY

  


  if(ballX >= 400 || ballY >= 400 || ballY <= 0 || ballX <= 0 ) {
    ballX = random(0,400);
    ballY = random(0,400);
    directionX = random(-5,5)
  directionY = random(-5,5)


  }
}